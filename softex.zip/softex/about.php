<?php
$pageTitle    = 'About Us — Our Story, Team & Mission';
$pageDesc     = 'Learn about Softex Technologies — founded in 2015 in Lahore, Pakistan. Our story, vision, mission, and the talented team behind Pakistan\'s leading software development company.';
$pageKeywords = 'about Softex Technologies, software development company Lahore, web design team Pakistan, IT company Pakistan 2015';
require_once 'includes/header.php';
?>

<section class="page-hero">
  <div class="orb orb-or" style="width:600px;height:600px;top:-180px;left:-100px;opacity:.8"></div>
  <div class="orb orb-cy" style="width:350px;height:350px;bottom:0;right:-60px;opacity:.5"></div>
  <div class="hero-grid-bg"></div>
  <div class="wrap">
    <div class="page-hero-content" data-reveal>
      <nav class="breadcrumb"><a href="index.php">Home</a><span class="sep"> › </span><span>About Us</span></nav>
      <div class="eyebrow" style="margin:0 auto 1rem"><i class="fas fa-users"></i> Our Story</div>
      <h1 class="h1" style="margin-bottom:1rem">Who We <span class="gradient-text">Are</span></h1>
      <p class="lead" style="margin:0 auto">A team of technologists, designers and strategists on a mission to transform businesses through world-class digital solutions.</p>
    </div>
  </div>
</section>

<!-- WHO WE ARE -->
<section class="section">
  <div class="wrap">
    <div class="split">
      <div class="split-visual" data-reveal>
        <div class="img-frame">
          <img src="https://images.unsplash.com/photo-1556761175-4b46a572b786?w=720&q=80" alt="Softex Technologies team" loading="lazy">
        </div>
        <div class="img-badge">
          <div class="num">2015</div>
          <div class="lbl">Year Founded</div>
        </div>
      </div>
      <div class="split-text" data-reveal data-delay="2">
        <div class="eyebrow"><i class="fas fa-building"></i> Our Story</div>
        <h2 class="h2" style="margin-bottom:1.1rem">Born to Build, <span class="gradient-text">Built to Grow</span></h2>
        <p>In 2015, a technologist and an innovator saw an opportunity for customizing technology to solve unique business problems that off-the-shelf products couldn't — and so <strong style="color:var(--t1)">Softex Technologies</strong> was born.</p>
        <p>With our agile methodologies and in-depth industry knowledge, we have gained the reputation of a leading software and e-commerce company in the region, extending our hands across the globe in providing world-class solutions.</p>
        <p>Our motto — <em style="color:var(--or)">"Start of a New Technology Era"</em> — guides us to not only emerge as a leading solution provider but also to build a team of technology experts and dedicated professionals passionate about creating the finest solutions.</p>
        <a href="contact.php" class="btn btn-primary" style="margin-top:.5rem">Work With Us <i class="fas fa-arrow-right"></i></a>
      </div>
    </div>
  </div>
</section>

<!-- VISION / MISSION / STRENGTH -->
<section class="section" style="background:var(--bg1)">
  <div class="wrap">
    <div class="center" data-reveal>
      <div class="eyebrow"><i class="fas fa-compass"></i> Our Core</div>
      <h2 class="h2" style="margin-bottom:1rem">What Makes Us <span class="gradient-text">Unique</span></h2>
    </div>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:1.5rem;margin-top:3rem">
      <?php foreach([
        ['🎯','Our Vision',   'To transform businesses, people and communities by embracing the power of technology with our motto "Start of a New Technology Era".'],
        ['🚀','Our Mission',  'To enable our clients to realize the full potential of their business by consistently offering world-class technological products, services and solutions to enhance their profitability and perception.'],
        ['💪','Our Strength', 'Softex believes in autonomy of decision making and functions. We have developed various departments under one umbrella — each with their own driving factors and individuality.'],
      ] as $i=>[$ico,$t,$d]): ?>
      <div class="svc-card" data-reveal data-delay="<?= $i+1 ?>">
 
        <h3 class="svc-title"><?= $t ?></h3>
        <p class="svc-desc"><?= $d ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- STATS -->
<section class="section" style="padding-top:0;background:var(--bg1)">
  <div class="wrap">
    <div class="stats-band-inner">
      <div class="orb orb-or" style="width:280px;height:280px;top:-80px;right:10%;opacity:.5;position:absolute;filter:blur(80px)"></div>
      <div class="stats-grid">
        <?php foreach([['150','+','Successfully Launched Projects'],['10','K+','Users Use Our Products'],['20','+','Talented Team Members'],['7','+','Years of Experience']] as $i=>[$n,$s,$l]): ?>
        <div class="stat-box" data-reveal data-delay="<?= $i ?>">
          <div class="stat-num gradient-text"><span data-count="<?= $n ?>" data-suffix="<?= $s ?>">0</span></div>
          <div class="stat-label"><?= $l ?></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<!-- TEAM -->
<section class="section">
  <div class="wrap">
    <div class="center" data-reveal>
      <div class="eyebrow"><i class="fas fa-user-friends"></i> Our Team</div>
      <h2 class="h2" style="margin-bottom:1rem">Meet Team <span class="gradient-text">Softex</span></h2>
      <p class="lead">We're a quirky bunch, but we all share the same core values: we're passionate, energetic, committed and gutsy!</p>
    </div>
    <div class="team-grid">
      <?php
      $team = [
        ['Ali Raza',        'Founder &amp; CEO',           '/assets/team/ali.jpg'],
        ['SamiUllah',       'Vice President Technology',   '/assets/team/sami.jpg'],
        ['Sameer Danish',    'Full Stack Developer',         '/assets/team/sameer.jpeg'],
        ['Asif Ullah',      'Project Manager',             '/assets/team/asif.png'],
        ['Faheem Aslam',    'Full Stack Developer',        '/assets/team/faheem.jpg'],
        ['Ali Raza Kamyana','Head of Legal Affairs',       '/assets/team/ali-kam.jpg'],
        ['Nasir Ashraf',    'Digital Media Manager',       '/assets/team/nasir.jpg'],
        ['Mohsin Amjad',    'Director Business Development','/assets/team/mohsin.jpg'],
      ];
      foreach($team as $i=>[$name,$role,$img]): ?>
      <div class="team-card" data-reveal data-delay="<?= ($i%4)+1 ?>">
        <div class="team-photo">
          <img src="<?= $img ?>" alt="<?= strip_tags($name) ?> — <?= strip_tags($role) ?>" loading="lazy"
               onerror="this.src='https://ui-avatars.com/api/?name=<?= urlencode(html_entity_decode($name)) ?>&background=f97316&color=fff&size=285'">
        </div>
        <div class="team-info">
          <div class="team-name"><?= $name ?></div>
          <div class="team-role"><?= $role ?></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- CTA -->
<section class="cta-band">
  <div class="orb orb-or" style="width:500px;height:500px;top:50%;left:50%;transform:translate(-50%,-50%)"></div>
  <div class="wrap">
    <div data-reveal>
      <div class="cta-box">
        <h2>Does Your Need Match <span class="gradient-text">Our Expertise?</span></h2>
        <p>Let's build something great together. Get a free consultation and project proposal today.</p>
        <div class="cta-btns">
          <a href="contact.php" class="btn btn-primary btn-lg"><i class="fas fa-rocket"></i> Get Free Proposal</a>
          <a href="services.php" class="btn btn-ghost btn-lg">Explore Services</a>
        </div>
      </div>
    </div>
  </div>
</section>

<?php require_once 'includes/footer.php'; ?>
