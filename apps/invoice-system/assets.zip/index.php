<?php
/**
 * Dashboard Overview Panel
 * Displays summary analytics, real-time revenue, and action shortcuts.
 */
require_once 'config.php';
require_login();

// Retrieve summary counts from database
try {
    // 1. Total Invoices
    $total_invoices_stmt = $pdo->query("SELECT COUNT(*) FROM invoices");
    $total_invoices = $total_invoices_stmt->fetchColumn();

    // 2. Paid Invoices Count
    $paid_invoices_stmt = $pdo->query("SELECT COUNT(*) FROM invoices WHERE status = 'PAID'");
    $paid_invoices = $paid_invoices_stmt->fetchColumn();

    // 3. Unpaid Invoices Count
    $unpaid_invoices_stmt = $pdo->query("SELECT COUNT(*) FROM invoices WHERE status = 'UNPAID'");
    $unpaid_invoices = $unpaid_invoices_stmt->fetchColumn();

    // 4. Total Revenue (Sum of PAID invoices total)
    $revenue_stmt = $pdo->query("SELECT SUM(ii.total) FROM invoice_items ii 
                                 JOIN invoices i ON ii.invoice_id = i.id 
                                 WHERE i.status = 'PAID'");
    $total_revenue = $revenue_stmt->fetchColumn() ?: 0.00;

    // 5. Outstanding Amount (Sum of UNPAID invoices total)
    $outstanding_stmt = $pdo->query("SELECT SUM(ii.total) FROM invoice_items ii 
                                     JOIN invoices i ON ii.invoice_id = i.id 
                                     WHERE i.status = 'UNPAID'");
    $total_outstanding = $outstanding_stmt->fetchColumn() ?: 0.00;

    // 6. Recent Invoices
    $recent_invoices_stmt = $pdo->query("SELECT i.*, c.name as client_name, 
                                         (SELECT SUM(ii.total) FROM invoice_items ii WHERE ii.invoice_id = i.id) as grand_total 
                                         FROM invoices i 
                                         JOIN clients c ON i.client_id = c.id 
                                         ORDER BY i.created_at DESC LIMIT 5");
    $recent_invoices = $recent_invoices_stmt->fetchAll();

    // 7. Recent Clients
    $recent_clients_stmt = $pdo->query("SELECT * FROM clients ORDER BY created_at DESC LIMIT 5");
    $recent_clients = $recent_clients_stmt->fetchAll();

} catch (PDOException $e) {
    die("Data Query Error: " . $e->getMessage());
}

include 'header.php';
?>

<!-- Metric Row -->
<div class="row g-4 mb-4">
  <!-- Metric Card: Revenue -->
  <div class="col-xl-3 col-md-6">
    <div class="card card-action-hover border-0 shadow-sm h-100 overflow-hidden" style="border-left: 5px solid #10b981 !important;">
      <div class="card-body p-4 position-relative">
        <div class="position-absolute end-0 bottom-0 mb-n3 me-n2 text-success opacity-10">
          <i class="bi bi-cash-stack" style="font-size: 6rem;"></i>
        </div>
        <div class="d-flex align-items-center justify-content-between mb-3">
          <span class="text-uppercase fw-bold text-muted small tracking-wider">Total Revenue Paid</span>
          <div class="bg-success-subtle p-2 rounded-3 text-success">
            <i class="bi bi-wallet2 fs-5"></i>
          </div>
        </div>
        <h3 class="fw-bold mb-1 text-dark"><?= format_currency($total_revenue) ?></h3>
        <p class="text-xs text-muted mb-0">From <?= h($paid_invoices) ?> paid invoices</p>
      </div>
    </div>
  </div>

  <!-- Metric Card: Outstanding Balance -->
  <div class="col-xl-3 col-md-6">
    <div class="card card-action-hover border-0 shadow-sm h-100 overflow-hidden" style="border-left: 5px solid #ef4444 !important;">
      <div class="card-body p-4 position-relative">
        <div class="position-absolute end-0 bottom-0 mb-n3 me-n2 text-danger opacity-10">
          <i class="bi bi-clock-history" style="font-size: 6rem;"></i>
        </div>
        <div class="d-flex align-items-center justify-content-between mb-3">
          <span class="text-uppercase fw-bold text-muted small tracking-wider">Outstanding Receivable</span>
          <div class="bg-danger-subtle p-2 rounded-3 text-danger">
            <i class="bi bi-exclamation-octagon fs-5"></i>
          </div>
        </div>
        <h3 class="fw-bold mb-1 text-dark"><?= format_currency($total_outstanding) ?></h3>
        <p class="text-xs text-muted mb-0">From <?= h($unpaid_invoices) ?> unpaid statements</p>
      </div>
    </div>
  </div>

  <!-- Metric Card: Total Invoices -->
  <div class="col-xl-3 col-md-6">
    <div class="card card-action-hover border-0 shadow-sm h-100 overflow-hidden" style="border-left: 5px solid #4f46e5 !important;">
      <div class="card-body p-4 position-relative">
        <div class="position-absolute end-0 bottom-0 mb-n3 me-n2 text-indigo opacity-10" style="color: #4f46e5;">
          <i class="bi bi-file-earmark-ruled" style="font-size: 6rem;"></i>
        </div>
        <div class="d-flex align-items-center justify-content-between mb-3">
          <span class="text-uppercase fw-bold text-muted small tracking-wider">Total Invoices Issued</span>
          <div class="bg-primary-subtle p-2 rounded-3 text-primary">
            <i class="bi bi-receipt fs-5"></i>
          </div>
        </div>
        <h3 class="fw-bold mb-1 text-dark"><?= h($total_invoices) ?></h3>
        <p class="text-xs text-muted mb-0">Across all registered clients</p>
      </div>
    </div>
  </div>

  <!-- Metric Card: Collection Rate -->
  <div class="col-xl-3 col-md-6">
    <div class="card card-action-hover border-0 shadow-sm h-100 overflow-hidden" style="border-left: 5px solid #06b6d4 !important;">
      <div class="card-body p-4 position-relative">
        <div class="position-absolute end-0 bottom-0 mb-n3 me-n2 text-info opacity-10">
          <i class="bi bi-percent" style="font-size: 6rem;"></i>
        </div>
        <div class="d-flex align-items-center justify-content-between mb-3">
          <span class="text-uppercase fw-bold text-muted small tracking-wider">Collection Efficiency</span>
          <div class="bg-info-subtle p-2 rounded-3 text-info">
            <i class="bi bi-graph-up-arrow fs-5"></i>
          </div>
        </div>
        <?php
          $collection_rate = ($total_invoices > 0) ? round(($paid_invoices / $total_invoices) * 100) : 0;
        ?>
        <h3 class="fw-bold mb-1 text-dark"><?= $collection_rate ?>%</h3>
        <div class="progress" style="height: 6px;">
          <div class="progress-bar bg-info" role="progressbar" style="width: <?= $collection_rate ?>%" aria-valuenow="<?= $collection_rate ?>" aria-valuemin="0" aria-valuemax="100"></div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Main Action Quick Links -->
<div class="row g-4 mb-4">
  <div class="col-md-4">
    <a href="invoice-create.php" class="card border-0 shadow-sm p-3 text-decoration-none d-flex flex-row align-items-center gap-3 card-action-hover h-100">
      <div class="bg-primary-subtle rounded-3 p-3 text-primary">
        <i class="bi bi-file-earmark-plus fs-4"></i>
      </div>
      <div>
        <h6 class="fw-bold text-dark mb-1">Create Invoice</h6>
        <p class="text-muted small mb-0">Generate a custom bill statement</p>
      </div>
    </a>
  </div>
  <div class="col-md-4">
    <a href="clients.php" class="card border-0 shadow-sm p-3 text-decoration-none d-flex flex-row align-items-center gap-3 card-action-hover h-100">
      <div class="bg-success-subtle rounded-3 p-3 text-success">
        <i class="bi bi-person-plus fs-4"></i>
      </div>
      <div>
        <h6 class="fw-bold text-dark mb-1">Add New Client</h6>
        <p class="text-muted small mb-0">Register client demographics</p>
      </div>
    </a>
  </div>
  <div class="col-md-4">
    <a href="settings.php" class="card border-0 shadow-sm p-3 text-decoration-none d-flex flex-row align-items-center gap-3 card-action-hover h-100">
      <div class="bg-warning-subtle rounded-3 p-3 text-warning">
        <i class="bi bi-sliders fs-4"></i>
      </div>
      <div>
        <h6 class="fw-bold text-dark mb-1">System Settings</h6>
        <p class="text-muted small mb-0">Setup profile and SMTP configs</p>
      </div>
    </a>
  </div>
</div>

<div class="row g-4">
  <!-- Left Side: Recent Invoices -->
  <div class="col-xl-8">
    <div class="card border-0 shadow-sm mb-4">
      <div class="card-header d-flex justify-content-between align-items-center">
        <h6 class="fw-bold text-dark mb-0"><i class="bi bi-file-earmark-ruled me-2"></i>Recent Invoices</h6>
        <a href="invoices.php" class="btn btn-sm btn-outline-primary py-1 px-3">View All</a>
      </div>
      <div class="card-body p-0">
        <div class="table-responsive">
          <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
              <tr>
                <th class="ps-4">Invoice No.</th>
                <th>Client</th>
                <th>Due Date</th>
                <th class="text-end">Grand Total</th>
                <th class="text-center">Status</th>
                <th class="pe-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if (empty($recent_invoices)): ?>
                <tr>
                  <td colspan="6" class="text-center py-4 text-muted">No invoices available.</td>
                </tr>
              <?php else: ?>
                <?php foreach ($recent_invoices as $invoice): ?>
                  <tr>
                    <td class="ps-4 fw-semibold text-primary"><a href="invoice-view.php?id=<?= $invoice['id'] ?>" class="text-decoration-none"><?= h($invoice['invoice_number']) ?></a></td>
                    <td>
                      <div class="fw-semibold text-dark"><?= h($invoice['client_name']) ?></div>
                    </td>
                    <td>
                      <i class="bi bi-calendar-event text-muted me-1 small"></i>
                      <span><?= h($invoice['due_date']) ?></span>
                    </td>
                    <td class="text-end fw-bold text-dark"><?= format_currency($invoice['grand_total']) ?></td>
                    <td class="text-center">
                      <?php if ($invoice['status'] === 'PAID'): ?>
                        <span class="badge badge-paid rounded-pill">PAID</span>
                      <?php else: ?>
                        <span class="badge badge-unpaid rounded-pill">UNPAID</span>
                      <?php endif; ?>
                    </td>
                    <td class="text-center pe-4">
                      <div class="btn-group">
                        <a href="invoice-view.php?id=<?= $invoice['id'] ?>" class="btn btn-sm btn-light" title="View Detail">
                          <i class="bi bi-eye"></i>
                        </a>
                        <a href="invoice-pdf.php?id=<?= $invoice['id'] ?>&download=1" class="btn btn-sm btn-light text-danger" title="Download PDF">
                          <i class="bi bi-file-pdf"></i>
                        </a>
                      </div>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  <!-- Right Side: Recent Clients -->
  <div class="col-xl-4">
    <div class="card border-0 shadow-sm">
      <div class="card-header d-flex justify-content-between align-items-center">
        <h6 class="fw-bold text-dark mb-0"><i class="bi bi-people me-2"></i>New Clients Added</h6>
        <a href="clients.php" class="btn btn-sm btn-outline-primary py-1 px-3">View All</a>
      </div>
      <div class="card-body p-0">
        <div class="list-group list-group-flush">
          <?php if (empty($recent_clients)): ?>
            <div class="text-center py-4 text-muted">No clients registered yet.</div>
          <?php else: ?>
            <?php foreach ($recent_clients as $client): ?>
              <div class="list-group-item p-3 d-flex align-items-center justify-content-between">
                <div class="d-flex align-items-center gap-3">
                  <div class="bg-light rounded-circle p-2 text-primary d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                    <i class="bi bi-person"></i>
                  </div>
                  <div>
                    <span class="fw-bold text-dark d-block" style="font-size: 0.9rem;"><?= h($client['name']) ?></span>
                    <span class="text-muted d-block" style="font-size: 0.75rem;"><?= h($client['email'] ?: 'No email registered') ?></span>
                  </div>
                </div>
                <div class="text-end">
                  <a href="clients.php?edit_id=<?= $client['id'] ?>" class="btn btn-sm btn-light" title="Edit Client">
                    <i class="bi bi-pencil-square text-primary"></i>
                  </a>
                </div>
              </div>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include 'footer.php'; ?>
