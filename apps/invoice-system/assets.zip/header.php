<?php
/**
 * Global Header Template
 * Provides navigation, sidebar, and core styles.
 */
require_once 'config.php';
require_login();

// Active class helper
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Softex Invoice Management System</title>
  <!-- Bootstrap 5 CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.min.css" rel="stylesheet">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  
  <style>
    :root {
      --primary-color: #4f46e5;
      --primary-hover: #4338ca;
      --secondary-color: #0f172a;
      --bg-light: #f8fafc;
      --card-border: #e2e8f0;
      --sidebar-width: 260px;
    }

    body {
      font-family: 'Plus Jakarta Sans', sans-serif;
      background-color: var(--bg-light);
      color: #334155;
      overflow-x: hidden;
    }

    /* Scrollbar */
    ::-webkit-scrollbar {
      width: 6px;
      height: 6px;
    }
    ::-webkit-scrollbar-track {
      background: #f1f5f9;
    }
    ::-webkit-scrollbar-thumb {
      background: #cbd5e1;
      border-radius: 4px;
    }
    ::-webkit-scrollbar-thumb:hover {
      background: #94a3b8;
    }

    /* Sidebar Styles */
    .sidebar {
      position: fixed;
      top: 0;
      bottom: 0;
      left: 0;
      width: var(--sidebar-width);
      z-index: 100;
      background-color: var(--secondary-color);
      color: #fff;
      transition: all 0.3s ease;
      box-shadow: 4px 0 10px rgba(0,0,0,0.05);
    }

    .sidebar-brand {
      height: 70px;
      display: flex;
      align-items: center;
      padding: 0 1.5rem;
      border-bottom: 1px solid rgba(255,255,255,0.08);
    }

    .sidebar-menu {
      padding: 1.5rem 0;
      height: calc(100vh - 140px);
      overflow-y: auto;
    }

    .menu-item {
      display: flex;
      align-items: center;
      padding: 0.75rem 1.5rem;
      color: #94a3b8;
      text-decoration: none;
      transition: all 0.2s ease;
      font-weight: 500;
      border-left: 4px solid transparent;
      margin-bottom: 0.25rem;
    }

    .menu-item:hover {
      color: #fff;
      background-color: rgba(255,255,255,0.05);
    }

    .menu-item.active {
      color: #fff;
      background-color: rgba(79, 70, 229, 0.15);
      border-left-color: var(--primary-color);
    }

    .menu-item i {
      font-size: 1.25rem;
      margin-right: 1rem;
      transition: all 0.2s ease;
    }

    .menu-item.active i {
      color: var(--primary-color);
    }

    .sidebar-footer {
      height: 70px;
      border-top: 1px solid rgba(255,255,255,0.08);
      display: flex;
      align-items: center;
      padding: 0 1.5rem;
      background-color: #090d16;
    }

    /* Main Content */
    .main-wrapper {
      margin-left: var(--sidebar-width);
      transition: all 0.3s ease;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }

    /* Top Navbar */
    .top-navbar {
      height: 70px;
      background-color: #fff;
      border-bottom: 1px solid var(--card-border);
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 2rem;
      position: sticky;
      top: 0;
      z-index: 99;
    }

    .page-content {
      padding: 2rem;
      flex-grow: 1;
    }

    /* Cards */
    .card {
      background-color: #fff;
      border: 1px solid var(--card-border);
      border-radius: 12px;
      box-shadow: 0 1px 3px rgba(0,0,0,0.02), 0 1px 2px rgba(0,0,0,0.03);
      transition: transform 0.2s ease, box-shadow 0.2s ease;
    }

    .card-action-hover:hover {
      transform: translateY(-2px);
      box-shadow: 0 10px 15px -3px rgba(0,0,0,0.05), 0 4px 6px -4px rgba(0,0,0,0.05);
    }

    .card-header {
      background-color: #fff;
      border-bottom: 1px solid var(--card-border);
      padding: 1.25rem 1.5rem;
      border-top-left-radius: 12px !important;
      border-top-right-radius: 12px !important;
    }

    /* Buttons */
    .btn-primary {
      background-color: var(--primary-color);
      border-color: var(--primary-color);
      padding: 0.5rem 1.25rem;
      font-weight: 500;
      border-radius: 8px;
    }

    .btn-primary:hover, .btn-primary:focus {
      background-color: var(--primary-hover);
      border-color: var(--primary-hover);
    }

    .btn-outline-primary {
      color: var(--primary-color);
      border-color: var(--primary-color);
      border-radius: 8px;
    }

    .btn-outline-primary:hover {
      background-color: var(--primary-color);
      color: #fff;
    }

    /* Badge Styles */
    .badge-paid {
      background-color: rgba(16, 185, 129, 0.15) !important;
      color: #10b981 !important;
      border: 1px solid rgba(16, 185, 129, 0.3);
      font-weight: 600;
      padding: 0.35em 0.65em;
    }

    .badge-unpaid {
      background-color: rgba(239, 68, 68, 0.15) !important;
      color: #ef4444 !important;
      border: 1px solid rgba(239, 68, 68, 0.3);
      font-weight: 600;
      padding: 0.35em 0.65em;
    }

    /* Custom Mobile Nav Toggle */
    .mobile-toggle {
      display: none;
      background: none;
      border: none;
      font-size: 1.5rem;
      cursor: pointer;
      color: #475569;
    }

    /* Footer */
    footer.app-footer {
      background-color: #fff;
      border-top: 1px solid var(--card-border);
      padding: 1.25rem 2rem;
      text-align: center;
      color: #64748b;
      font-size: 0.875rem;
    }

    @media (max-width: 991.98px) {
      .sidebar {
        margin-left: calc(-1 * var(--sidebar-width));
      }
      .sidebar.show {
        margin-left: 0;
      }
      .main-wrapper {
        margin-left: 0;
      }
      .mobile-toggle {
        display: block;
      }
    }
  </style>
</head>
<body>

  <!-- Sidebar -->
  <aside class="sidebar" id="app-sidebar">
    <div class="sidebar-brand">
      <div class="d-flex align-items-center gap-2">
        <div class="bg-primary rounded-3 p-1 text-white d-flex align-items-center justify-content-center" style="width: 35px; height: 35px;">
          <i class="bi bi-receipt-cutoff" style="font-size: 1.25rem;"></i>
        </div>
        <div>
          <span class="fw-bold fs-5 tracking-tight d-block leading-none text-white">Softex Invoicing</span>
          <span class="text-xs text-muted" style="font-size: 0.7rem; letter-spacing: 0.05rem;">MANAGEMENT PORTAL</span>
        </div>
      </div>
    </div>
    
    <div class="sidebar-menu">
      <a href="index.php" class="menu-item <?= ($current_page == 'index.php') ? 'active' : '' ?>">
        <i class="bi bi-speedometer2"></i>
        <span>Dashboard</span>
      </a>
      <a href="clients.php" class="menu-item <?= ($current_page == 'clients.php' || $current_page == 'client-add.php' || $current_page == 'client-edit.php') ? 'active' : '' ?>">
        <i class="bi bi-people"></i>
        <span>Clients</span>
      </a>
      <a href="invoices.php" class="menu-item <?= ($current_page == 'invoices.php' || $current_page == 'invoice-create.php' || $current_page == 'invoice-edit.php' || $current_page == 'invoice-view.php') ? 'active' : '' ?>">
        <i class="bi bi-file-earmark-ruled"></i>
        <span>Invoices</span>
      </a>
      <a href="settings.php" class="menu-item <?= ($current_page == 'settings.php') ? 'active' : '' ?>">
        <i class="bi bi-gear"></i>
        <span>Settings</span>
      </a>
    </div>

    <div class="sidebar-footer">
      <div class="d-flex align-items-center gap-2 w-100">
        <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center text-white font-bold" style="width: 36px; height: 36px; font-size: 0.9rem;">
          SA
        </div>
        <div class="overflow-hidden flex-grow-1">
          <span class="fw-semibold text-white d-block text-truncate" style="font-size: 0.85rem;"><?= h($_SESSION['admin_name'] ?? 'Admin') ?></span>
          <span class="text-muted d-block text-truncate" style="font-size: 0.75rem;"><?= h($_SESSION['admin_user'] ?? 'admin@softex.pk') ?></span>
        </div>
        <a href="logout.php" class="text-danger ms-auto" title="Log Out" onclick="return confirm('Are you sure you want to log out?')">
          <i class="bi bi-box-arrow-right fs-5"></i>
        </a>
      </div>
    </div>
  </aside>

  <!-- Main Wrapper -->
  <div class="main-wrapper">
    <!-- Top Navbar -->
    <header class="top-navbar">
      <div class="d-flex align-items-center gap-3">
        <button class="mobile-toggle" id="sidebar-toggle-btn" aria-label="Toggle Sidebar">
          <i class="bi bi-list"></i>
        </button>
        <h5 class="mb-0 fw-semibold text-dark">
          <?php
            if ($current_page == 'index.php') echo 'Overview Dashboard';
            elseif ($current_page == 'clients.php') echo 'Client Registry';
            elseif ($current_page == 'invoices.php') echo 'Billing Invoices';
            elseif ($current_page == 'invoice-create.php') echo 'New Billing Invoice';
            elseif ($current_page == 'invoice-edit.php') echo 'Edit Invoice details';
            elseif ($current_page == 'invoice-view.php') echo 'Invoice Summary';
            elseif ($current_page == 'settings.php') echo 'System Preferences';
            else echo 'Invoice Management';
          ?>
        </h5>
      </div>
      
      <div class="d-flex align-items-center gap-3">
        <div class="text-end d-none d-md-block">
          <span class="text-xs text-muted d-block" style="font-size: 0.75rem;">Today's Date</span>
          <span class="fw-semibold text-dark" style="font-size: 0.85rem;"><?= date('F d, Y') ?></span>
        </div>
        <div class="vr mx-1 d-none d-md-block"></div>
        <a href="invoice-create.php" class="btn btn-primary d-flex align-items-center gap-2">
          <i class="bi bi-plus-lg"></i>
          <span>Create Invoice</span>
        </a>
      </div>
    </header>

    <!-- Page Content Area -->
    <main class="page-content">
      <!-- Flash message display -->
      <?= display_flash_message() ?>
